package com.example.lab1_judy;

import android.app.Activity;

public class MainActivity extends Activity {
}
